<?php 
class Hybrid_Providers_Stackoverflow extends Hybrid_Provider_Model_OpenID
{
	var $openidIdentifier = "https://openid.stackexchange.com/";
}