##### Translate WSL to another language

Are you fluent in English or any other language? Help us translate WordPress Social Login.

WordPress Social Login translations are hosted at https://www.transifex.com/projects/p/wordpress-social-login/.